BOT_TOKEN = '6543334235:AAFhto_CqFgH4a5hrTNgxKQaPx0R-5ArI6s'

PREFIX = "!/."

ANTISPAM = int(120)

OWNER = 743175202

APP_ID = ""

API_HASH = ''

SESSION = ""

OWNERID = int(5579729798)

OWNER_NAME = "<a href='tg://user?id=5579729798'>⏤͟͞B3</a>"

CHANNEL = "https://t.me/Raven_Ccs"

GROUP = "https://t.me/raven_group"

OWNER_LINK = "https://t.me/b3owner"

from database import check_user, check_admin

def check_owner(id):
  if id == OWNER: return True
def ok(id):
  if check_owner(id):
    user = "OWNER"
    return user
  if check_admin(id) == True:
    user = "ADMIN"
    return user

  elif check_user(id) == True:
    user = "PAID"
    return user

  elif check_user(id) == False or check_admin(id) == False:
    user = "FREE"
    return user

  else:
    user = "FREE"
    return user
